# Pavlin Online Store

Welcome to Pavlin, whether casual or formal, find the perfect jewerly for every occasion with us

## Overview

The main leitmotif of the Pavlin Boutique brand is a combination of aesthetics, ecological and exclusivity of each piece of jewellery. The selection of minerals is individual. The jewellery design is created taking into account local custom features and natural curls of the stones. We are for the originilaty of the natural gem world and therefore we use minerals with minimum processing. The result is not only visual aesthetics but also benelovent gem contact with human skin.

## Preview

![Pavlin Preview](screenshot.png)
